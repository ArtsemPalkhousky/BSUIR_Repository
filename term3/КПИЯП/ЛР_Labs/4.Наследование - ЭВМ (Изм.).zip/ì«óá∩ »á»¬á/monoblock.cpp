#include "monoblock.h"

Monoblock::Monoblock(){
	cout << "Constructor MONOBLOCK" << endl << endl;
	memCap = 0;
}

Monoblock::~Monoblock(){
	cout << "Destructor MONOBLOCK" << endl;
}

void Monoblock::setMemCap(int memCap){
	this->memCap = memCap;
}

int Monoblock::getMemCap(){
	return memCap;
}

istream& operator >> (istream& in, Monoblock& monoblock){
	Static* stat;
	stat = &monoblock;
	cout << endl << "input MONOBLOCK" << endl;
	in >> *(dynamic_cast<Static*>(stat));
	cout << "Memory Capacity(int) - ";
	in >> monoblock.memCap;
	return in;
}

ostream& operator << (ostream& out, Monoblock& monoblock){
	Static* stat;
	stat = &monoblock;
	out << endl << "MONOBLOCK";
	out << *(dynamic_cast<Static*>(stat));
	out << "Memory Capacity: " << monoblock.memCap;
	return out;
}