#pragma once
#include "Portative_Class.h"

class Smartphone : public Portable{
private:
	string screen;
	double screenSize;
public:
	Smartphone();
	~Smartphone();
	friend istream& operator >> (istream& in, Smartphone& mphome);
	friend ostream& operator << (ostream& out, Smartphone& mphone);
	void setScreen(string screen);
	string getScreen();
	void setScreenSize(double screenSize);
	double getScreenSize();
};