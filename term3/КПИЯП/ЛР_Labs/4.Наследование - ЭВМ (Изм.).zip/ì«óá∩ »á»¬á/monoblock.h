#pragma once
#include "Stationary_Class.h"

class Monoblock : public Static{
private:
	int memCap;
public:
	Monoblock();
	~Monoblock();
	friend istream& operator >> (istream& in, Monoblock& monoblock);
	friend ostream& operator << (ostream& out, Monoblock& monoblock);
	void setMemCap(int memCap);
	int getMemCap();
};