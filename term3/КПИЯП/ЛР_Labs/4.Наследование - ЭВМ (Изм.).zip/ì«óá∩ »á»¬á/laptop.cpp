#include "laptop.h"

Notebook::Notebook(){
	cout << "Constructor NOTEBOOK" << endl << endl;
	graphicCard = '\0';
	GCmodel = 0;
	weight = 0.0;
}

Notebook::~Notebook(){
	cout << "Destructor NOTEBOOK" << endl;
}

void Notebook::setGraphicCard(string graphicCard){
	this->graphicCard = graphicCard;
}

string Notebook::getGraphicCard(){
	return graphicCard;
}

void Notebook::setGCmodel(int GCmodel){
	this->GCmodel = GCmodel;
}

int Notebook::getGCmodel(){
	return GCmodel;
}

void Notebook::setWeight(double weight){
	this->weight = weight;
}

double Notebook::getWeight(){
	return weight;
}

istream& operator>>(istream& in, Notebook& notebook){
	Portable* portable;
	portable = &notebook;
	cout << endl << "input LAPTOP" << endl;
	in >> *(dynamic_cast<Portable*>(portable));
	cout << "Graphic card(string) - ";
	in >> notebook.graphicCard;
	cout << "Graphic card model(int) - ";
	in >> notebook.GCmodel;
	cout << "Weight(int) - ";
	in >> notebook.weight;
	return in;
}

ostream& operator<<(ostream& out, Notebook& notebook){
	Portable* portable;
	portable = &notebook;
	cout << endl << "LAPTOP";
	out << *(dynamic_cast<Portable*>(portable));
	out << "Graphic card: " << notebook.graphicCard << "|";
	out << "Graphic card model: " << notebook.GCmodel << "|";
	out << "Weight: " << notebook.weight;
	return out;
}