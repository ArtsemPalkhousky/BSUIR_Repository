#include "COMPUTER.h"

Computer::Computer(){
	cout << "Constructor COMPUTER" << endl;
	brand = '\0';
}

Computer::~Computer(){
	cout << "Destructor COMPUTER" << endl << endl;
}

void Computer::setBrand(string brand){
	this->brand = brand;
}

string Computer::getBrand(){
	return brand;
}

istream& operator>>(istream& in, Computer& computer){
	cout << "Enter brand(string) - ";
	in >> computer.brand;
	return in;
}

ostream& operator<<(ostream& out, const Computer& computer){
	out << "|" << "Brand: " << computer.brand << "|";
	return out;
}