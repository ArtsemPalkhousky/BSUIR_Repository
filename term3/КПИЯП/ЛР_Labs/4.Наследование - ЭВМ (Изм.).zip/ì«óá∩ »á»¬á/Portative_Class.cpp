#include "Portative_Class.h"

Portable::Portable(){
	cout << "Constructor PORTATIVE" << endl;
	battery = 0;
}

Portable::~Portable(){
	cout << "Destructor PORTATIVE" << endl;
}

void Portable::setBattery(int battery){
	this->battery = battery;
}

int Portable::getBattery(){
	return battery;
}

istream& operator >> (istream& in, Portable& portable){
	Computer* computer;
	computer = &portable;
	in >> *(dynamic_cast<Computer*>(computer));
	cout << "Enter battery(int) - ";
	in >> portable.battery;
	return in;
}

ostream& operator << (ostream& out, Portable& portable){
	Computer* computer;
	computer = &portable;
	out << *(dynamic_cast<Computer*>(computer));
	out << "Battery: " << portable.battery << "|";
	return out;
}