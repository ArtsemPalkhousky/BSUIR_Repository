#include "monoblock.h"
#include "server.h"
#include "smartphone.h"
#include "laptop.h"

int main()
{
	Monoblock monoblock;
	Server server;
	Smartphone phone;
	Notebook notebook;

	cin >> monoblock;
	cin >> server;
	cin >> phone;
	cin >> notebook;

	cout << monoblock;
	cout << server;
	cout << phone;
	cout << notebook;
	cout << endl << endl;
	

	cout << endl << "Phone brand - " << phone.getBrand() << endl;		//������ ������� � ������ set & get
	cout << "Server Hard Drive capacity - " << server.getMemHD() << endl;
	cout << "Laptop battery - " << notebook.getBattery() << endl;		
	int b = server.getVoltage();
	monoblock.setBrand("--");
	monoblock.setVoltage(b);
	monoblock.setMemCap(0);
	int past = 0;
	phone.setBrand("0000");
	phone.setScreen("--");
	phone.setBattery(past);
	phone.setScreenSize(past);
	notebook.setBrand("0000");
	notebook.setGraphicCard("000");
	notebook.setBattery(0);
	notebook.setWeight(0);
	notebook.setGCmodel(0);

	system("PAUSE");
	cout << endl << "MODIFICATED:" << endl;
	cout << monoblock;
	cout << server;
	cout << phone;
	cout << notebook;
	cout << endl << endl;
	system("PAUSE");
}