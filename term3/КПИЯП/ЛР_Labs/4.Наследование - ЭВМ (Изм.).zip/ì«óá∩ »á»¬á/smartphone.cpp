#include "smartphone.h"

Smartphone::Smartphone() {
	cout << "Constructor SMARTPHONE" << endl << endl;
	screen = '\0';
	screenSize = 0.0;
}

Smartphone::~Smartphone() {
	cout << "Destructor SMARTPHONE" << endl;
}

void Smartphone::setScreen(string screen) {
	this->screen = screen;
}

string Smartphone::getScreen() {
	return screen;
}

void Smartphone::setScreenSize(double screenSize) {
	this->screenSize = screenSize;
}

double Smartphone::getScreenSize() {
	return screenSize;
}

istream& operator >> (istream& in, Smartphone& mphome) {
	Portable* portable;
	portable = &mphome;
	cout << endl << "input SMARTPHONE" << endl;
	in >> *(dynamic_cast<Portable*>(portable));
	cout << "Screen(stting): ";
	in >> mphome.screen;
	cout << "Screen size(int): ";
	in >> mphome.screenSize;
	return in;
}

ostream& operator << (ostream& out, Smartphone& mphone) {
	Portable* portable;
	portable = &mphone;
	cout << endl << "SMARTPHONE";
	out << *(dynamic_cast<Portable*>(portable));
	out << "Screen: " << mphone.screen << "|";
	out << "Screen size: " << mphone.screenSize;
	return out;
}