#include "server.h"

Server::Server(){
	cout << "Constructor SERVER" << endl << endl;
	memHD = 0;
}

Server::~Server(){
	cout << "Destcructor SERVER" << endl;
}

void Server::setMemHD(int memHD){
	this->memHD = memHD;
}

int Server::getMemHD(){
	return memHD;
}

istream& operator >> (istream& in, Server& server){
	Static* stat;
	stat = &server;
	cout << endl << "input SERVER" << endl;
	in >> *(dynamic_cast<Static*>(stat));
	cout << "Hard Drive capacity(int) - ";
	in >> server.memHD;
	return in;
}

ostream& operator << (ostream& out, Server& server){
	Static* stat;
	stat = &server;
	cout << endl << "SERVER";
	out << *(dynamic_cast<Static*>(stat));
	out << "Hard Drive capacity: " << server.memHD;
	return out;
}